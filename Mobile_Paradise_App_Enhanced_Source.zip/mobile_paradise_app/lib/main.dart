import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const MobileParadiseApp());

const String whatsappNumber = '919238412633';
// IMPORTANT: Replace this with the shop's real UPI ID before publishing.
const String upiId = 'YOUR_UPI_ID@upi';
const String merchantName = 'Mobile Paradise';
const int advanceBookingAmount = 500;

class Product {
  final String name;
  final int price;
  final String image;
  const Product(this.name, this.price, this.image);
}

const products = <Product>[
  Product('iPhone 13', 7000, 'assets/products/iphone_13.png'),
  Product('iPhone 14', 8000, 'assets/products/iphone_14.png'),
  Product('iPhone 14 Plus', 8000, 'assets/products/iphone_14_plus.png'),
  Product('iPhone 15', 9000, 'assets/products/iphone_15.png'),
  Product('iPhone 15 Plus', 9000, 'assets/products/iphone_15_plus.png'),
  Product('iPhone 16', 10000, 'assets/products/iphone_16.png'),
  Product('iPhone 16 E', 11000, 'assets/products/iphone_16_e.png'),
  Product('iPhone 15 Pro', 11000, 'assets/products/iphone_15_pro.png'),
  Product('iPhone 15 Pro Max', 12000, 'assets/products/iphone_15_pro_max.png'),
  Product('iPhone 16 Pro', 12000, 'assets/products/iphone_16_pro.png'),
  Product('iPhone 16 Pro Max', 13000, 'assets/products/iphone_16_pro_max.png'),
];

class MobileParadiseApp extends StatelessWidget {
  const MobileParadiseApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Mobile Paradise',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF080808),
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFFFFC107),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
        ),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final List<Product> cart = [];
  final List<OrderRecord> orders = [];

  void addToCart(Product p) {
    setState(() => cart.add(p));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${p.name} cart me add ho gaya')),
    );
  }

  void removeFromCart(Product p) {
    setState(() => cart.remove(p));
  }

  void saveOrder(OrderRecord order) {
    setState(() => orders.insert(0, order));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeTab(onShop: () => setState(() => tab = 1)),
      ProductsTab(onAdd: addToCart),
      CartTab(cart: cart, onRemove: removeFromCart, onOrderSaved: saveOrder),
      OrdersTab(orders: orders),
    ];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text('MOBILE PARADISE',
            style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1)),
        centerTitle: true,
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.phone_android), label: 'Mobiles'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), label: 'Cart'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Orders'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  final VoidCallback onShop;
  const HomeTab({super.key, required this.onShop});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: Image.asset('assets/logo.png', height: 280, fit: BoxFit.cover),
          ),
          const SizedBox(height: 18),
          const Text('Mobile Paradise',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('Shopping • Order • iPhone Offers • All India Delivery',
              style: TextStyle(color: Colors.white70, fontSize: 15)),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: onShop,
            icon: const Icon(Icons.shopping_bag_outlined),
            label: const Text('SHOP NOW'),
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFFFC107),
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
          ),
          const SizedBox(height: 18),
          const InfoCard(icon: Icons.location_on_outlined, title: 'Shop Address', text: 'Rohtak, Haryana'),
          const InfoCard(icon: Icons.local_shipping_outlined, title: 'Delivery', text: 'All India Delivery'),
          const InfoCard(icon: Icons.payments_outlined, title: 'Payment', text: 'UPI + Advance Booking Option'),
          const InfoCard(icon: Icons.chat_outlined, title: 'Order', text: 'Customer order WhatsApp par directly aayega'),
        ],
      );
}

class InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  const InfoCard({super.key, required this.icon, required this.title, required this.text});
  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          leading: Icon(icon, color: const Color(0xFFFFC107)),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(text),
        ),
      );
}

class ProductsTab extends StatelessWidget {
  final void Function(Product) onAdd;
  const ProductsTab({super.key, required this.onAdd});

  @override
  Widget build(BuildContext context) => ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: products.length,
        itemBuilder: (_, i) {
          final p = products[i];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            clipBehavior: Clip.antiAlias,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Container(
                    width: 100,
                    height: 125,
                    decoration: BoxDecoration(
                      color: const Color(0xFF151515),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    padding: const EdgeInsets.all(8),
                    child: Image.asset(p.image, fit: BoxFit.contain),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 5),
                        Text('₹${p.price}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Color(0xFFFFC107))),
                        const SizedBox(height: 5),
                        const Text('Original • Seal Packed', style: TextStyle(color: Colors.white70, fontSize: 12)),
                        const SizedBox(height: 8),
                        FilledButton.icon(
                          onPressed: () => onAdd(p),
                          icon: const Icon(Icons.add_shopping_cart, size: 18),
                          label: const Text('ADD TO CART'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
}

class CartTab extends StatelessWidget {
  final List<Product> cart;
  final void Function(Product) onRemove;
  final void Function(OrderRecord) onOrderSaved;
  const CartTab({super.key, required this.cart, required this.onRemove, required this.onOrderSaved});

  @override
  Widget build(BuildContext context) {
    final total = cart.fold<int>(0, (sum, p) => sum + p.price);
    if (cart.isEmpty) return const Center(child: Text('Cart abhi khaali hai'));
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ...cart.asMap().entries.map((entry) {
          final p = entry.value;
          return Card(
            child: ListTile(
              leading: Image.asset(p.image, width: 42, height: 55, fit: BoxFit.contain),
              title: Text(p.name),
              subtitle: Text('₹${p.price}'),
              trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => onRemove(p)),
            ),
          );
        }),
        const Divider(height: 28),
        Text('Total: ₹$total', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text('Advance booking: ₹$advanceBookingAmount', style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => CheckoutPage(cart: cart, onOrderSaved: onOrderSaved)),
          ),
          icon: const Icon(Icons.shopping_cart_checkout),
          label: const Padding(padding: EdgeInsets.all(12), child: Text('PROCEED TO BOOK / ORDER')),
        ),
      ],
    );
  }
}

class OrderRecord {
  final String customer;
  final String phone;
  final int total;
  final DateTime time;
  final String status;
  const OrderRecord({required this.customer, required this.phone, required this.total, required this.time, required this.status});
}

class CheckoutPage extends StatefulWidget {
  final List<Product> cart;
  final void Function(OrderRecord) onOrderSaved;
  const CheckoutPage({super.key, required this.cart, required this.onOrderSaved});
  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  final city = TextEditingController(text: 'Rohtak');
  final state = TextEditingController(text: 'Haryana');
  String payment = 'Advance ₹$advanceBookingAmount';

  @override
  void dispose() {
    name.dispose(); phone.dispose(); address.dispose(); city.dispose(); state.dispose(); super.dispose();
  }

  int get total => widget.cart.fold<int>(0, (s, p) => s + p.price);

  String buildOrderMessage() {
    final items = widget.cart.map((p) => '• ${p.name} - ₹${p.price}').join('\n');
    return '''Hello Mobile Paradise,

NEW CUSTOMER ORDER / BOOKING

Customer: ${name.text.trim()}
Phone: ${phone.text.trim()}
Address: ${address.text.trim()}, ${city.text.trim()}, ${state.text.trim()}

Products:
$items

Total: ₹$total
Payment option: $payment
Advance booking charge: ₹$advanceBookingAmount

Please confirm availability, final price, delivery and payment status.''';
  }

  Future<void> placeOrder() async {
    if (!formKey.currentState!.validate()) return;
    final order = OrderRecord(
      customer: name.text.trim(),
      phone: phone.text.trim(),
      total: total,
      time: DateTime.now(),
      status: payment == 'Advance ₹$advanceBookingAmount' ? 'Advance pending' : 'Order sent',
    );
    widget.onOrderSaved(order);

    if (payment == 'Advance ₹$advanceBookingAmount') {
      await payAdvance();
    }
    await sendWhatsAppOrder();
  }

  Future<void> payAdvance() async {
    if (upiId.startsWith('YOUR_')) {
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('UPI ID set karna hai'),
          content: const Text('App me payment button ready hai. Publish/build se pehle shop ka real UPI ID main.dart me dalna hoga.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ),
      );
      return;
    }
    final uri = Uri.parse(
      'upi://pay?pa=${Uri.encodeComponent(upiId)}&pn=${Uri.encodeComponent(merchantName)}&am=$advanceBookingAmount&cu=INR&tn=${Uri.encodeComponent('Mobile Paradise advance booking')}',
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> sendWhatsAppOrder() async {
    final uri = Uri.parse('https://wa.me/$whatsappNumber?text=${Uri.encodeComponent(buildOrderMessage())}');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (mounted) Navigator.pop(context);
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('WhatsApp open nahi ho paya.')));
    }
  }

  InputDecoration decoration(String label, IconData icon) => InputDecoration(labelText: label, prefixIcon: Icon(icon), border: const OutlineInputBorder());

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Book / Order')), 
        body: Form(
          key: formKey,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text('Order Summary', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              ...widget.cart.map((p) => ListTile(
                    dense: true,
                    leading: Image.asset(p.image, width: 35, height: 45, fit: BoxFit.contain),
                    title: Text(p.name),
                    trailing: Text('₹${p.price}'),
                  )),
              const Divider(),
              Text('Total: ₹$total', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              const Text('Advance booking charge: ₹500', style: TextStyle(color: Color(0xFFFFC107), fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              TextFormField(controller: name, decoration: decoration('Full Name', Icons.person_outline), validator: (v) => v == null || v.trim().isEmpty ? 'Name bhariye' : null),
              const SizedBox(height: 12),
              TextFormField(controller: phone, keyboardType: TextInputType.phone, decoration: decoration('Mobile Number', Icons.phone_outlined), validator: (v) => v == null || v.trim().length < 10 ? 'Valid mobile number bhariye' : null),
              const SizedBox(height: 12),
              TextFormField(controller: address, maxLines: 3, decoration: decoration('Delivery Address', Icons.home_outlined), validator: (v) => v == null || v.trim().isEmpty ? 'Address bhariye' : null),
              const SizedBox(height: 12),
              TextFormField(controller: city, decoration: decoration('City', Icons.location_city)),
              const SizedBox(height: 12),
              TextFormField(controller: state, decoration: decoration('State', Icons.map_outlined)),
              const SizedBox(height: 18),
              const Text('Payment option', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
              RadioListTile<String>(value: 'Advance ₹$advanceBookingAmount', groupValue: payment, onChanged: (v) => setState(() => payment = v!), title: Text('Advance booking ₹$advanceBookingAmount + remaining on confirmation')),
              RadioListTile<String>(value: 'Pay after confirmation', groupValue: payment, onChanged: (v) => setState(() => payment = v!), title: const Text('Pay after order confirmation')),
              const SizedBox(height: 6),
              if (payment == 'Advance ₹$advanceBookingAmount')
                OutlinedButton.icon(onPressed: payAdvance, icon: const Icon(Icons.account_balance_wallet_outlined), label: Text('PAY ₹$advanceBookingAmount ADVANCE VIA UPI')),
              const SizedBox(height: 10),
              FilledButton.icon(onPressed: placeOrder, icon: const Icon(Icons.chat), label: const Padding(padding: EdgeInsets.all(14), child: Text('CONFIRM & SEND ORDER ON WHATSAPP'))),
              const SizedBox(height: 10),
              const Text('Order details aapke Mobile Paradise WhatsApp par bheje jayenge.', style: TextStyle(color: Colors.white60), textAlign: TextAlign.center),
            ],
          ),
        ),
      );
}

class OrdersTab extends StatelessWidget {
  final List<OrderRecord> orders;
  const OrdersTab({super.key, required this.orders});
  @override
  Widget build(BuildContext context) {
    if (orders.isEmpty) {
      return const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Abhi koi order nahi. Customer order WhatsApp par bhi aayega.', textAlign: TextAlign.center)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: orders.length,
      itemBuilder: (_, i) {
        final o = orders[i];
        return Card(
          child: ListTile(
            leading: const Icon(Icons.receipt_long, color: Color(0xFFFFC107)),
            title: Text(o.customer, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${o.phone}\n₹${o.total} • ${o.status}'),
            isThreeLine: true,
          ),
        );
      },
    );
  }
}
