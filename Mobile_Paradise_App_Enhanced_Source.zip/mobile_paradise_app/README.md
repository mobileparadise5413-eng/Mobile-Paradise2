# Mobile Paradise

Flutter shopping/order app for Mobile Paradise, Rohtak, Haryana.

## Included in this version
- All supplied iPhone models and prices
- Product image cards for every model
- Cart with remove option
- Customer name, phone and delivery address
- Advance booking charge: ₹500
- UPI payment button (replace `YOUR_UPI_ID@upi` in `lib/main.dart` with the shop's real UPI ID)
- WhatsApp order handoff to `+91 9238412633`
- Local order list inside the app during the current app session
- All India Delivery messaging

## Important payment note
The UPI button launches the customer's UPI app. It does not automatically verify a successful payment. For automatic payment verification, a real payment gateway such as Razorpay/other provider and its merchant credentials/backend are required.

## Build
```bash
flutter pub get
flutter build apk --release
```

For the GitHub Actions workflow, the workflow should first run `flutter create .` if the source ZIP does not contain Android project files.
